# [FPS 게임 프로젝트] 소스 코드 제출 안내

본 압축 파일은 넥슨 서류 전형 제출을 위해 전체 프로젝트 중 핵심 로직이 담긴 `Assets/Scripts` 폴더의 구조를 그대로 유지하여 구성한 소스 코드입니다. 전체 프로젝트 소스 및 커밋 히스토리는 아래 GitHub 저장소에서 확인하실 수 있습니다.

* **GitHub Repository:** https://github.com/MDJ0126/FPSGame

---

## 🛠️ 개발 환경
- **Engine:** Unity 2021.3.19f1 (LTS)
- **Language:** C#
- **Platform:** PC (Windows)

---

## 📂 폴더 구조 및 핵심 소스 코드 안내

서류 검토의 편의를 위해 주요 기능별로 폴더를 분류하였으며, 핵심적인 아키텍처가 포함된 `Character` 폴더의 상세 구조는 다음과 같습니다.

### Character (캐릭터 시스템 및 상속 구조)
캐릭터의 상태 관리와 컴포넌트 기반 제어, 플레이어 및 AI(봇, 좀비)의 개별 확장 구조를 포함하고 있습니다.

* **기반 및 상태 관리 (Base & Core)**
  - `Character.cs`: 플레이어와 AI의 공통 최상위 기반(Base) 클래스입니다. 체력, 상태, 사망 처리 등 캐릭터의 핵심 데이터를 관리합니다.
  - `PartsRendererManager.cs`: 캐릭터의 파츠별 렌더러를 동적으로 제어하고 관리하는 매니저 스크립트입니다.

* **플레이어 구현부 (Player)**
  - `PlayerCharacter.cs`: `Character`를 상속받아 구현된 플레이어 고유 클래스입니다.
  - `PlayerInputController.cs`: 플레이어의 키보드/마우스 입력을 캡처하여 전달하는 입력 제어 컴포넌트입니다.

* **AI 및 몬스터 구현부 (AI & Bot)**
  - `AICharacter.cs`: AI 기반 생명체의 공통 확장 클래스입니다.
  - `AIComponent.cs`: AI 행동 트리를 보조하는 컴포넌트입니다.
  - `DetectTarget.cs`: 주변 타겟(플레이어 등)을 탐지하고 추적하기 위한 시야/센서 로직입니다.
  - `BotCharacter.cs` / `BotAI.cs`: 일반적인 AI 봇의 캐릭터 속성과 상태 제어(FSM/Behavior) 로직입니다.
  - `Zombie.cs` / `ZombieAI.cs`: 근접 공격 및 특수 행동 패턴을 가진 좀비 몬스터의 속성과 AI 로직입니다.

* **행동 및 애니메이션 제어 컴포넌트 (Actions & Animation)**
  - `MoveController.cs`: 플레이어 및 AI의 이동 및 물리 처리를 유기적으로 담당하는 컴포넌트입니다.
  - `WeaponHandler.cs`: 무기 장착, 조준, 사격 등의 메커니즘을 캐릭터와 연결하는 컴포넌트입니다.
  - `HitCollider.cs`: 부위별 피격 판정(Headshot 등)을 정밀하게 처리하기 위한 충돌체 제어 스크립트입니다.
  - `AnimatorController.cs` / `AnimatorReceiver.cs`: 애니메이션 파라미터 제어 및 애니메이션 이벤트 신호를 수신하여 로직과 동기화하는 스크립트입니다.

---

## 구현 시 중점을 둔 부분
- **객체 지향 프로그래밍(OOP) 및 상속 구조 활용:** 최상위 `Character` 및 `AICharacter` 클래스를 설계하고, 이를 플레이어(`PlayerCharacter`), AI(`BotCharacter`, `Zombie`)가 상속받아 확장하는 명확한 아키텍처를 구축했습니다.
- **컴포넌트 기반 설계 (CBD):** 이동(`MoveController`), 무기 제어(`WeaponHandler`), 입력(`PlayerInputController`), 애니메이션 수신(`AnimatorReceiver`) 등의 핵심 기능을 독립된 컴포넌트로 분리하여, 캐릭터 타입에 관계없이 조립 및 재사용이 가능하도록 유연성을 확보했습니다.
- **모듈화된 AI 시스템:** 타겟 탐지(`DetectTarget`)와 핵심 AI 로직(`BotAI`, `ZombieAI`)을 캐릭터 본체와 분리하여 상태 전환(FSM) 및 행동 패턴의 유지보수성을 높였습니다.