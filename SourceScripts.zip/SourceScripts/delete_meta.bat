@echo off
chcp 65001 > nul
echo 현재 폴더 및 하위 폴더의 모든 .meta 파일을 삭제합니다...
echo 진행하시려면 아무 키나 누르세요. (취소하려면 창을 닫으세요)
pause

:: 현재 경로 및 하위 경로의 .meta 파일 강제 삭제 (/f: 강제, /s: 하위 폴더 포함, /q: 조용히)
del /f /s /q "*.meta"

echo.
echo 모든 .meta 파일이 성공적으로 삭제되었습니다!
pause